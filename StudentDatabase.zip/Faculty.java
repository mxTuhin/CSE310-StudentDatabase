public class Faculty {
    public String name;
    public String sid;
    public String email;
    public String password;
    public String toString()
    {
        return "Student Name : " + name + "\n"
                + "Student ID : " + sid + "\n"
                + "Email Address : " + email + "\n"
                + "Password : " + password + "\n";
    }
}
